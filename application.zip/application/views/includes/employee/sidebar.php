<aside class="left-sidebar mini-side">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">

                <!-- <li> <a class="waves-effect waves-dark" href="<//?= base_url('student_dashboard') ?>" aria-expanded="false"><i class="icon-Dashboard"></i><span class="hide-menu">Student Dashboard</span></a>
                </li> -->
                <li> <a class="waves-effect waves-dark" href="<?= base_url('employee') ?>" aria-expanded="false"><i class="icon-File-HorizontalText "></i><span class="hide-menu">Document / Teaching</span></a>
                </li>
                <li> <a class="waves-effect waves-dark" href="<?= base_url('employee/meeting_notes') ?>" aria-expanded="false"><i class="icon-Note  "></i><span class="hide-menu">Meeting Notes</span></a>
                </li>
                <li> <a class="waves-effect waves-dark" href="<?= base_url('employee/company_policies') ?>" aria-expanded="false"><i class="icon-Notepad  "></i><span class="hide-menu">Company Policies</span></a>
                </li>

                </li>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>
