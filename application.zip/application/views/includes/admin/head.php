<div class="preloader">
	<div class="pre_cont">Loading Please wait... </div>
</div>
<div id="dash_right_info">
<div class="dash_intro">
	<a class="btn_logout" href="<?=base_url("logout")?>">Logout</a>
	<h2> <?= get_logged_name()?></h2>
	<figure><img src="<?= base_url("assets/") ?>images/sample_profile.png" alt=""></figure>
	<!-- <div class="show_hover">
		<ul>
			<li><a href="">Update Profile</a></li>
			<li><a href="">Logout</a></li>
		</ul>1
	</div> -->
</div>