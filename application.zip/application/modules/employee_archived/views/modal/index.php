
<?php
  $this->load->view("modal/view_modal");
  $this->load->view("modal/edit_modal");
?>