<?php
  $this->load->view("modal/addmodal");
  $this->load->view("modal/editmodal");
?>