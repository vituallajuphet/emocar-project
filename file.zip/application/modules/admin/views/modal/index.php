<?php
  $this->load->view("modal/viewmodal");
  $this->load->view("modal/editmodal");
  $this->load->view("modal/addmodal");
?>